package test;

import java.nio.ByteBuffer;

/**
 * 이 프로젝트는 최종 뫼 프레임워크에 추가되었습니다.
 */
public interface AsyncCallback
{
	/**
	 * 각종 로그들을 출력합니다.
	 * @param msg
	 */
	public abstract void onLog(String msg);
	
	/**
	 * 각종 오류를 출력합니다.
	 * @param e
	 */
	public abstract void onSoftError(Exception e);
	
	/**
	 * 각종 오류를 출력합니다.
	 * @param e
	 */
	public abstract void onError(Exception e);
	
	/**
	 * 소켓 통신 확립
	 * @param socket
	 * @param remotePort
	 */
	public abstract void onCreateSocket(AsyncSocket socket, int remotePort);
	
	/**
	 * 소켓 닫힘
	 * @param socket
	 * @param remotePort
	 */
	public abstract void onDestroySocket(AsyncSocket socket, int remotePort);
	
	/**
	 * 최종 
	 * @param socket
	 * @param readBuffer
	 * @param size
	 */
	public abstract void onRead(AsyncSocket socket, ByteBuffer readBuffer, int size);
}
