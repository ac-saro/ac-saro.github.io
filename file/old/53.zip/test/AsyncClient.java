package test;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousChannelGroup;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.concurrent.Executors;

/**
 * 2016-02-13 전명 박용서 : 작성<br>
 * Asynchronous SSL Client<br>
 * 이 프로젝트는 최종 뫼 프레임워크에 추가되었습니다.
 */
public abstract class AsyncClient implements AsyncCallback
{
	// SSL 컨텍스트 / 그룹 / 채널
	private AsynchronousSocketChannel channel;
	private AsyncSocket socket = null;
	
	/**
	 * 소켓을 호출합니다.
	 * @return
	 */
	public AsyncSocket getSocket()
	{
		return socket;
	}
	
	/**
	 * 소켓을 전송합니다.
	 * @param buffer
	 */
	public void write(byte[] buffer)
	{
		socket.write(buffer);
	}
	
	/**
	 * 소켓을 전송합니다.
	 * @param buffer
	 */
	public void write(ByteBuffer buffer)
	{
		socket.write(buffer);
	}
	
	/**
	 * 연결을 시도합니다.
	 * @param sslContext
	 * @param host
	 * @param port
	 * @param threadCount
	 */
	public void connect(String host, int port, int threadCount, int socketReadBufferSize)
	{
		try
		{
			// 그룹생성 / 채널생성 / 채널 확인 / 바인드
			AsynchronousChannelGroup channelGroup = AsynchronousChannelGroup.withFixedThreadPool(threadCount, Executors.defaultThreadFactory());
			
			// 채널을 열고 채널이 열렸는지 확인한다.
			channel = AsynchronousSocketChannel.open(channelGroup);
			if (!channel.isOpen()) { throw new IOException("fail open AsynchronousSocketChannel"); }
			
			// 연결시도
			channel.connect(new InetSocketAddress(host, port), channel, new CompletionHandler<Void, AsynchronousSocketChannel>()
			{
				@Override
				public void completed(Void result, AsynchronousSocketChannel asynchronousSocketChannel)
				{
					try
					{
						// 소캣 생성 / 시작
						socket = new AsyncSocket(channel, AsyncClient.this, socketReadBufferSize);
						socket.beginReader();
					}
					catch (Exception e)
					{
						e.printStackTrace();
					}
				}
		
				@Override
				public void failed(Throwable e, AsynchronousSocketChannel channel)
				{
					if (socket != null)
					{
						socket.close(new Exception(e));
					}
					else if (channel != null)
					{
						onError(new Exception(e));
						if (channel.isOpen()) { try { channel.close(); } catch (Exception e2) { onError(e2); } }
					}
				}
			});
		}
		catch (Exception e)
		{
			if (socket != null)
			{
				socket.close(new Exception(e));
			}
			else if (channel != null)
			{
				onError(new Exception(e));
				if (channel.isOpen()) { try { channel.close(); } catch (Exception e2) { onError(e2); } }
			}
		}
	}
	
	/**
	 * 연결상태
	 * @return
	 */
	public boolean isOpen()
	{
		return socket != null && socket.isOpen();
	}
}
