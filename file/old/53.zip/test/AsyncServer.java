package test;

import java.net.InetSocketAddress;
import java.nio.channels.AsynchronousChannelGroup;
import java.nio.channels.AsynchronousServerSocketChannel;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.concurrent.Executors;

/**
 * 2016-02-13 전명 박용서 : 작성<br>
 * 이 프로젝트는 최종 뫼 프레임워크에 추가되었습니다.
 */
public abstract class AsyncServer implements AsyncCallback
{
	// SSL 컨텍스트 / 그룹 / 채널
	private AsynchronousChannelGroup channelGroup;
	private AsynchronousServerSocketChannel serverChannel;
	
	/**
	 * 통신중인 모든 소켓<br>
	 * 주의 : 임의로 추가/삭제를 할경우 시스템이 꼬일 수 있습니다.<br>
	 * 특별한 경우가 아니면 사용하지 않고 onCreateSocket / onDestroySocket 를 상속하여 사용합니다.<br>
	 */
	final protected HashMap<Integer, AsyncSocket> map = new HashMap<>();
	
	
	/**
	 * 서버를 가동합니다.
	 * @param port
	 * @param threadCount
	 * @param socketReadBufferSize
	 * @return
	 */
	public boolean startup(int port, int threadCount, int socketReadBufferSize)
	{
		try
		{
			// 그룹생성 / 채널생성 / 채널 확인 / 바인드
			channelGroup = AsynchronousChannelGroup.withFixedThreadPool(threadCount, Executors.defaultThreadFactory());
			serverChannel = AsynchronousServerSocketChannel.open(channelGroup);
			if (!serverChannel.isOpen()) { throw new Exception("fail asynchronousServerSocketChannel open"); }
			serverChannel.bind(new InetSocketAddress(port));
			
			onLog("server startup");
			
			// 엑셉 선언
			serverChannel.accept(serverChannel, new CompletionHandler<AsynchronousSocketChannel, AsynchronousServerSocketChannel>()
			{
				// 엑샙 호출
				@Override public void completed(AsynchronousSocketChannel channel, AsynchronousServerSocketChannel serverChannel)
				{
					// 서버 채널에 대한 인자를 제대로 받았는지 확인 후 엑셉에 완료했다는 메시지를 보낸다.
					if (serverChannel == null) { return; }
					// 다음 엑셉이 와도 좋다는 신호이다.
					serverChannel.accept(serverChannel, this);
					AsyncSocket socket = null;
					
					onLog("new accept");
					
					try
					{
						// 소캣 생성 / 시작
						socket = new AsyncSocket(channel, AsyncServer.this, socketReadBufferSize);
						socket.beginReader();
						onLog("new accept done - port : " + Integer.toString(socket.getRemotePort()));
					}
					catch (Exception e)
					{
						if (socket != null)
						{
							socket.close(e);
						}
						else
						{
							if (serverChannel.isOpen()) { try { serverChannel.close(); } catch (Exception e2) { onError(e2); } }
							onError(new Exception(e));
						}
					}
				}
				
				// 오류 발생
				@Override public void failed(Throwable e, AsynchronousServerSocketChannel serverChannel)
				{
					if (serverChannel.isOpen()) { try { serverChannel.close(); } catch (Exception e2) { onError(e2); } }
					onError(new Exception(e));
				}
			});
		}
		
		// 초기로드 실패
		catch (Exception e)
		{
			onError(e);
			shutdown();
			return false;
		}
		
		return true;
	}
	
	/**
	 * 채널이 열려있는지 확인합니다.
	 * @return
	 */
	public boolean isOpen()
	{
		return serverChannel != null && serverChannel.isOpen();
	}
	
	/**
	 * 소켓을 종료합니다.
	 * @param unit
	 */
	public void onDisconnect(AsyncSocket unit)
	{
		if (unit != null)
		{
			map.remove(unit.getRemotePort());
			unit.close();
		}
	}
	
	/**
	 * 서버를 종료합니다.<br>
	 * 직접 map 을 정상적으로 비운 후 실행을 권장합니다.
	 */
	public synchronized void shutdown()
	{
		// 모든 연결을 닫습니다.
		Iterator<Entry<Integer, AsyncSocket>> ieMap = map.entrySet().iterator();
		while (ieMap.hasNext())
		{
			AsyncSocket sock = ieMap.next().getValue();
			ieMap.remove();
			sock.close();
		}
		if (serverChannel != null && serverChannel.isOpen()) { try { serverChannel.close(); } catch (Exception e) { onError(e); } }
		if (channelGroup != null && (!channelGroup.isShutdown())) { channelGroup.shutdown(); }
		onLog("server shutdown");
	}
	
	/**
	 * 연결이 확립된 소켓은 map에 추가합니다.<br>
	 * 주의 : 이 로직엔 매핑과정이 추가되어있습니다.<br>
	 * super를 통해 이 메서드를 실행하는 것을 권장합니다.
	 */
	@Override public void onCreateSocket(AsyncSocket socket, int remotePort)
	{
		map.put(remotePort, socket);
	}
	
	/**
	 * 연결이 끊어진 소켓을 map에서 제거합니다.<br>
	 * 주의 : 이 로직엔 매핑과정이 추가되어있습니다.<br>
	 * super를 통해 이 메서드를 실행하는 것을 권장합니다.
	 */
	@Override public void onDestroySocket(AsyncSocket socket, int remotePort)
	{
		map.remove(remotePort);
	}
}
