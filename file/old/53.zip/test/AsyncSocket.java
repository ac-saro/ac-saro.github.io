package test;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.HashMap;

/**
 * 2016-02-13 전명 박용서 : 작성<br>
 * 이 프로젝트는 최종 뫼 프레임워크에 추가되었습니다.
 */
public class AsyncSocket
{
	// 채널 / 엔진 / 세션 / 원격포트[주 아이디] / 콜백[서버 / 클라이언트]
	final private AsynchronousSocketChannel channel;
	final private int remotePort;
	final private AsyncCallback callback;
	
	// read 버퍼
	final private ByteBuffer readBuffer;
	
	// 덧붙여 쓸 수 있는 옵션들
	final private HashMap<Object, Object> attachMap = new HashMap<>();
	private Object attachObj = null;
	
	/**
	 * 새로운 소켓유닛을 만듭니다.
	 * @param channel
	 * @param sslEngine
	 * @param callback
	 * @throws IOException
	 */
	public AsyncSocket(AsynchronousSocketChannel channel, AsyncCallback callback, int socketReadBufferSize) throws IOException
	{
		// 채널 / 엔진 / 세션 / 원격포트[주 아이디] / 콜백
		this.channel = channel;
		this.remotePort = ((InetSocketAddress)channel.getRemoteAddress()).getPort();
		this.callback = callback;
		
		// 버퍼를 초기화 합니다.
		readBuffer = ByteBuffer.allocateDirect(socketReadBufferSize);
	}
	
	/**
	 * 원격 포트를 가져옵니다.
	 * @return 포트
	 */
	public int getRemotePort()
	{
		return this.remotePort;
	}
	
	/**
	 * 소켓채널을 가져옵니다.<br>
	 * 직접사용을 권장하는 않는 함수입니다.
	 * @return 채널
	 */
	public AsynchronousSocketChannel getAsynchronousSocketChannel()
	{
		return this.channel;
	}
	
	
	/**
	 * 버퍼를 전송합니다.
	 * @param buffer
	 */
	public void write(byte[] buffer)
	{
		write(ByteBuffer.wrap(buffer));
	}
	
	/**
	 * 버퍼를 전송합니다.
	 * @param buffer
	 */
	public synchronized void write(ByteBuffer buffer)
	{
		if (channel.isOpen())
		{
			try
			{
				while (buffer.hasRemaining())
				{
					channel.write(buffer).get();
				}
			}
			catch (Exception e)
			{
				this.close(e);
			}
		}
	}
	
	
	/**
	 * 핸드쉐이킹이 끝나고 리더를 실행합니다.<br>
	 * 특별한 경우가 없다면 한번만 호출하는 것을 권장하며<br>
	 * saro.moe.net.assl 의 Server / Client 에서 실행해줍니다.<br>
	 * 즉 특별한 일이 없다면 사용하지 않는 것을 권장합니다.
	 */
	protected void beginReader()
	{
		readBuffer.clear();
		channel.read(readBuffer, this, new CompletionHandler<Integer, AsyncSocket>()
		{
			@Override
			public void completed(Integer size, AsyncSocket socket)
			{
				ByteBuffer read = socket.readBuffer;
				
				if (size == -1)
				{
					socket.closeSoft(new Exception("read size -1 : connection error"));
					return;
				}
				
				// 소켓을 읽어 복호화 후 onRead 로 콜백합니다.
				if (size > 0)
				{
					try
					{
						read.flip();
						socket.callback.onRead(socket, read, read.limit() - read.position());
						read.compact();
					}
					catch (Exception e)
					{
						socket.close(e);
					}
				}
				
				// 다음 리드를 위해 읽었음을 표시합니다.
				socket.channel.read(read, socket, this);
			}

			@Override
			public void failed(Throwable e, AsyncSocket socket)
			{
				socket.closeSoft(new Exception(e));
			}
		});
		
		callback.onLog("bind reader");
		callback.onCreateSocket(this, remotePort);
	}
	
	/**
	 * 소켓에 사용자가 작성한 오브젝트를 붙입니다.
	 * @param obj
	 */
	public void setAttachObj(Object obj)
	{
		this.attachObj = obj;
	}
	
	/**
	 * 소켓에 붙여둔 오브젝트를 반환받습니다.
	 * @return
	 */
	public Object getAttachObj()
	{
		return this.attachObj;
	}
	
	/**
	 * 소켓에 사용자가 작성한 오브젝트를 hashmap에 추가합니다.
	 * @param key 
	 * @param val
	 * @return
	 * 해시맵으로 구현 되어있기 때문에 반환값 역시<br>
	 * 겹치는 key가 선택시 이전에 가지고 있던 값이 리턴됩니다.
	 */
	public Object setAttachMap(Object key, Object val)
	{
		return this.attachMap.put(key, val);
	}
	
	/**
	 * 소켓의 hashmap에 추가된 오브젝트를 반환받습니다.
	 * @param key
	 * @return
	 */
	public Object getAttachMap(Object key)
	{
		return this.attachMap.get(key);
	}
	
	/**
	 * 현재 열려있는지의 상태를 가져옵니다.
	 * @return
	 */
	public boolean isOpen()
	{
		if (channel.isOpen())
		{
			return true;
		}
		else
		{
			close();
			return false;
		}
	}
	
	/**
	 * 오류를 전송하고 채널을 닫습니다.
	 * @param e
	 */
	public void close(Exception e)
	{
		callback.onError(e);
		close();
	}
	
	/**
	 * 소프트 오류를 전송하고 채널을 닫습니다.
	 * @param e
	 */
	public void closeSoft(Exception e)
	{
		callback.onSoftError(e);
		close();
	}
	
	/**
	 * 소켓 채널을 닫습니다.
	 */
	public void close()
	{
		// 소켓이 닫혔음을 전송해줍니다.
		// 아직 닫히기 전에 전송해주는 이유는 현재 유닛이 다른 집단에 속해있을 경우
		// 닫히고 나서 전송하는 경우 해당 로직은 이 유닛이 살아있음으로 착각하고 더 큰 오류를 발생할 수 있기 때문에
		// 소켓이 닫혔음을 미리 전송하여 안전을 확보하고 소켓을 닫습니다.
		callback.onDestroySocket(this, remotePort);
		
		// 채널을 닫습니다.
		if (channel != null)
		{
			if (channel.isOpen()) { try { channel.close(); } catch(Exception e) { callback.onError(e); } }
		}
	}
}
