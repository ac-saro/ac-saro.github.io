package test;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;


/**
 * 작성 : 전명 박용서
 * 참고 : https://gs.saro.me/#m=elec&jn=534
 */
public class ChatClient
{
	final public static String HOST = "localhost";
	final public static int PORT = 19091;
	
	
	public static void main(String[] args) throws Exception
	{
		log("비동기 논블로킹 시스템콜 예제 - 클라이언트");
		
		
		MyClient client = new MyClient();
		client.connect(HOST, PORT, 30, 8192);
		
		startWriteLoop(client);
	}
	
	public static void startWriteLoop(MyClient client) throws Exception
	{
		log("메시지를 입력해주세요 : ");
		InputStream inputstream = System.in;
		InputStreamReader inputstreamreader = new InputStreamReader(inputstream);
		BufferedReader bufferedreader = new BufferedReader(inputstreamreader);
		String msg = null;
		while ((msg = bufferedreader.readLine()) != null)
		{
			if (!client.isOpen())
			{
				log("서버와 연결되지 않은 상태입니다.");
				continue;
			}
			client.write(NetUtil.toByteBufferUtf8(msg));
		}
	}

	public static class MyClient extends AsyncClient
	{

		@Override
		public void onLog(String msg)
		{
			log(msg);
		}

		@Override
		public void onError(Exception e)
		{
			e.printStackTrace();
		}

		@Override
		public void onCreateSocket(AsyncSocket socket, int remotePort)
		{
			log("서버에 접속되었습니다.");
		}

		@Override
		public void onDestroySocket(AsyncSocket socket, int remotePort)
		{
			log("서버와 연결이 끊어졌습니다.");
		}

		@Override
		public void onRead(AsyncSocket socket, ByteBuffer readBuffer, int size)
		{
			log(NetUtil.toStringUtf8(readBuffer));
		}

		@Override
		public void onSoftError(Exception e)
		{
			
		}
		
	}
	
	public static void log(String msg)
	{
		System.out.println("TID:" + Thread.currentThread().getId() + ":" + msg);
	}
}
