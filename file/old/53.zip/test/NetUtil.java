package test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;

/**
 * 이 프로젝트는 최종 뫼 프레임워크에 추가되었습니다.
 */
public class NetUtil
{
	final private static Charset UTF8 = Charset.forName("utf-8");
	
	/**
	 * ByteBuffer 로변환합니다.
	 * @param str
	 * @return
	 */
	public static ByteBuffer toByteBufferUtf8(String str)
	{
		return UTF8.encode(str);
	}
	
	/**
	 * 스트링으로 변환합니다.
	 * @param buffer
	 * @return
	 */
	public static String toStringUtf8(ByteBuffer buffer)
	{
		return UTF8.decode(buffer).toString();
	}
	
	/**
	 * 키 매니저를 생성합니다.<br>
	 * 형식과 알고리즘은 JKS / SunX509 입니다.
	 * @param file
	 * @param password
	 * @return
	 * @throws UnrecoverableKeyException
	 * @throws KeyStoreException
	 * @throws NoSuchAlgorithmException
	 * @throws CertificateException
	 * @throws IOException
	 */
	public static KeyManager[] getKeyManagers(InputStream file, char[] password)
			throws UnrecoverableKeyException, KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException
	{
		return getKeyManagers("JKS", "SunX509", file, password);
	}
	
	/**
	 * 키 매니저를 생성합니다.
	 * @param keyStoreType
	 * @param algorithm
	 * @param file
	 * @param password
	 * @return
	 * @throws IOException
	 * @throws UnrecoverableKeyException
	 * @throws KeyStoreException
	 * @throws NoSuchAlgorithmException
	 * @throws CertificateException
	 */
	public static KeyManager[] getKeyManagers(String keyStoreType, String algorithm, InputStream file, char[] password)
			throws IOException, UnrecoverableKeyException, KeyStoreException, NoSuchAlgorithmException, CertificateException
	{
		KeyStore keyStore = KeyStore.getInstance(keyStoreType);
		KeyManagerFactory kmf = KeyManagerFactory.getInstance(algorithm);
		try
		{
			keyStore.load(file, password);
			kmf.init(keyStore, password);
		}
		finally
		{
			if (file != null) { file.close(); }
		}
		return kmf.getKeyManagers();
	}
	
	/**
	 * 트러스트 매니저를 생성합니다.<br>
	 * 형식과 알고리즘은 JKS / SunX509 입니다.
	 * @param file
	 * @param password
	 * @return
	 * @throws UnrecoverableKeyException
	 * @throws KeyStoreException
	 * @throws NoSuchAlgorithmException
	 * @throws CertificateException
	 * @throws IOException
	 */
	public static TrustManager[] getTrustManagers(InputStream file, char[] password)
			throws UnrecoverableKeyException, KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException
	{
		return getTrustManagers("JKS", "SunX509", file, password);
	}
	
	/**
	 * 트러스트 매니저를 생성합니다.<br>
	 * @param file
	 * @param password
	 * @return
	 * @throws UnrecoverableKeyException
	 * @throws KeyStoreException
	 * @throws NoSuchAlgorithmException
	 * @throws CertificateException
	 * @throws IOException
	 */
	public static TrustManager[] getTrustManagers(String keyStoreType, String algorithm, InputStream file, char[] password)
			throws IOException, UnrecoverableKeyException, KeyStoreException, NoSuchAlgorithmException, CertificateException
	{
		KeyStore keyStore = KeyStore.getInstance(keyStoreType);
		TrustManagerFactory kmf = TrustManagerFactory.getInstance(algorithm);
		try
		{
			keyStore.load(file, password);
			kmf.init(keyStore);
		}
		finally
		{
			if (file != null) { file.close(); }
		}
		return kmf.getTrustManagers();
	}
	
	/**
	 * SSLContext 을 생성합니다.
	 * @param protocol
	 * @param keyManagers
	 * @param trustManagers
	 * @param random
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws KeyManagementException
	 */
	public static SSLContext createSSLContext(String protocol, KeyManager[] keyManagers, TrustManager[] trustManagers, SecureRandom random)
			throws NoSuchAlgorithmException, KeyManagementException 
	{
		SSLContext sslContext = SSLContext.getInstance(protocol);
		sslContext.init(keyManagers, trustManagers, random);
		return sslContext;
	}
	
	/**
	 * SSLContext 을 생성합니다.<br>
	 * 키 / 트러스트 스토어는 JKS / SunX509 이며 프로토콜은 TLS 입니다.
	 * @param keyStorePath
	 * @param keyStorePassword
	 * @param trustStorePath
	 * @param trustStorePassword
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws KeyManagementException
	 * @throws UnrecoverableKeyException
	 * @throws KeyStoreException
	 * @throws CertificateException
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public static SSLContext createSSLContext(String keyStorePath, char[] keyStorePassword, String trustStorePath, char[] trustStorePassword)
			throws NoSuchAlgorithmException, KeyManagementException, UnrecoverableKeyException, KeyStoreException, CertificateException, FileNotFoundException, IOException 
	{
		SSLContext sslContext = SSLContext.getInstance("TLS");
		sslContext.init(getKeyManagers(new FileInputStream(keyStorePath), keyStorePassword), getTrustManagers(new FileInputStream(trustStorePath), trustStorePassword), new SecureRandom());
		return sslContext;
	}
}
